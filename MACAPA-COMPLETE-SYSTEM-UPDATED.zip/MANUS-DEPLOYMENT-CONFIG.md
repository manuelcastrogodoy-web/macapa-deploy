# 🤖 CONFIGURACIÓN PARA MANUS.SPACE

## 📋 **PREPARACIÓN DE ARCHIVOS PARA MANUS**

### **Paso 1: Preparar Backend para Manus**

```bash
# Crear archivo de configuración específico para Manus
cd macapa-app/backend
```

**Crear `manus-config.json`:**
```json
{
  "name": "macapa-backend",
  "type": "nodejs",
  "version": "18",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "install": "npm install"
  },
  "environment": {
    "NODE_ENV": "production",
    "PORT": "8080",
    "GEMINI_API_KEY": "AIzaSyB8J-mt5VEkrSL3lwh68an_Ni9pbU4d29Q",
    "ZAPIER_WEBHOOK_SECRET": "manu_macapa_webhook_secret_2024",
    "ALLOWED_ORIGINS": "https://mafersapp-dcug8tre.manus.space",
    "RATE_LIMIT_WINDOW_MS": "900000",
    "RATE_LIMIT_MAX_REQUESTS": "100",
    "LOG_LEVEL": "info"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "dotenv": "^16.3.1",
    "body-parser": "^1.20.2",
    "@google/generative-ai": "^0.17.1",
    "axios": "^1.6.2",
    "uuid": "^9.0.1",
    "moment": "^2.29.4",
    "winston": "^3.11.0",
    "express-rate-limit": "^7.1.5",
    "joi": "^17.11.0"
  }
}
```

### **Paso 2: Preparar Frontend para Manus**

**Crear `frontend/manus-build.sh`:**
```bash
#!/bin/bash
# Script para build en Manus
npm install
REACT_APP_API_URL=https://mafersapp-dcug8tre.manus.space/api npm run build
```

**Crear `frontend/.env.manus`:**
```env
REACT_APP_API_URL=https://mafersapp-dcug8tre.manus.space/api
REACT_APP_ENVIRONMENT=production
GENERATE_SOURCEMAP=false
```

### **Paso 3: Archivos ZIP para Manus**

**Backend ZIP:**
```bash
cd backend
zip -r macapa-backend-manus.zip . -x "node_modules/*" ".git/*"
```

**Frontend ZIP (después del build):**
```bash
cd frontend
npm install
REACT_APP_API_URL=https://mafersapp-dcug8tre.manus.space/api npm run build
cd build
zip -r ../macapa-frontend-manus.zip .
```

## 🚀 **PASOS EN MANUS.SPACE**

### **Deploy Backend:**

1. **Subir a Manus:**
   - Ve a: https://mafersapp-dcug8tre.manus.space
   - Crear nuevo proyecto: "MACAPA Backend"
   - Subir `macapa-backend-manus.zip`

2. **Configurar Variables de Entorno:**
   ```
   NODE_ENV=production
   PORT=8080
   GEMINI_API_KEY=AIzaSyB8J-mt5VEkrSL3lwh68an_Ni9pbU4d29Q
   ZAPIER_WEBHOOK_SECRET=manu_macapa_webhook_secret_2024
   ALLOWED_ORIGINS=https://mafersapp-dcug8tre.manus.space
   RATE_LIMIT_WINDOW_MS=900000
   RATE_LIMIT_MAX_REQUESTS=100
   LOG_LEVEL=info
   ```

3. **Comando de Inicio:**
   ```bash
   npm install && node server.js
   ```

### **Deploy Frontend:**

1. **Subir Frontend:**
   - Crear nuevo proyecto: "MACAPA Dashboard"
   - Subir `macapa-frontend-manus.zip`
   - Configurar como sitio estático

2. **Configurar Proxy (Importante):**
   - Configurar proxy `/api/*` → Backend URL
   - Esto permite que frontend se comunique con backend

## 🔧 **CONFIGURACIÓN ESPECÍFICA MANUS**

### **Archivo `manus-deploy.yaml`:**
```yaml
# Configuración para Manus.space
projects:
  - name: macapa-backend
    type: nodejs
    runtime: node18
    build:
      command: npm install
    start:
      command: node server.js
    environment:
      NODE_ENV: production
      PORT: 8080
      GEMINI_API_KEY: AIzaSyB8J-mt5VEkrSL3lwh68an_Ni9pbU4d29Q
      ZAPIER_WEBHOOK_SECRET: manu_macapa_webhook_secret_2024
      ALLOWED_ORIGINS: https://mafersapp-dcug8tre.manus.space
    
  - name: macapa-frontend
    type: static
    build:
      command: npm install && npm run build
      output: build
    environment:
      REACT_APP_API_URL: https://mafersapp-dcug8tre.manus.space/api
```

## 📡 **URLs FINALES EN MANUS**

- **🌐 Dashboard**: `https://mafersapp-dcug8tre.manus.space`
- **🔗 API**: `https://mafersapp-dcug8tre.manus.space/api`
- **📡 Webhook**: `https://mafersapp-dcug8tre.manus.space/api/webhooks/zapier/agent-activity`

## ⚠️ **CONSIDERACIONES IMPORTANTES**

### **Limitaciones en Manus:**
1. **🔧 Configuración manual** más compleja
2. **💰 Posibles costos** según uso
3. **📊 Menos herramientas** de monitoreo
4. **🔄 Deploy manual** vs automático

### **Ventajas en Manus:**
1. **🏠 Ya tienes cuenta**
2. **🔗 Integración** con tus otros proyectos
3. **👥 Soporte directo** del equipo

## 🎯 **MI RECOMENDACIÓN FINAL**

**Usa RENDER** por estas razones:

1. **⏱️ Tiempo**: 15 min en Render vs 1-2 horas en Manus
2. **💰 Costo**: Gratis en Render vs posibles costos en Manus  
3. **🔧 Simplicidad**: Auto-deploy vs configuración manual
4. **📊 Herramientas**: Dashboard completo vs básico
5. **🛡️ Seguridad**: Automática vs manual

**Pero si insistes en Manus**, usa los archivos de configuración de arriba.

## 📞 **¿Necesitas Ayuda?**

Si decides usar Manus:
1. Sigue los pasos de arriba
2. Usa los archivos de configuración incluidos
3. Contacta soporte de Manus si hay problemas

**¡Pero te recomiendo RENDER para mejor experiencia!** 🚀